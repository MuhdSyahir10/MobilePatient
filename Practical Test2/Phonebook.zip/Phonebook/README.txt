Code Quest Solutions - Phonebook

Files generated: 19 Mar 2021 @ 11:39 EDT

This archive contains all of the inputs and outputs for the problem
named above. It also contains a selection of solutions to this problem,
written by Lockheed Martin volunteers or by students participating in
one of our contest events or our Lockheed Martin Code Quest Academy Website.

These solutions are provided for illustrative purposes only; they are not
meant to represent the "only" correct solution to this problem. In fact,
there is no single correct answer, and very often multiple algorithms could
be used to obtain a correct solution.

We ask that you do not post these solutions online, as this problem will
be posted to the Code Quest Academy Website soon, if it hasn't been already.
By keeping these solutions private, you maintain the challenge for anyone
who has yet to attempt this problem.

Thanks for your participation in Lockheed Martin Code Quest!
